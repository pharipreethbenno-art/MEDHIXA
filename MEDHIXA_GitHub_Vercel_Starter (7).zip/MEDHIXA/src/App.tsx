import { useState, type ReactNode } from 'react';
import { NavLink, Route, Routes, useNavigate } from 'react-router-dom';
import {
  BookOpen, BrainCircuit, GraduationCap, LayoutDashboard, Search,
  ClipboardCheck, Settings, Menu, X, Sparkles, Moon, Sun, ChevronRight,
  Send, Bot, User, BookMarked, Trophy, ArrowUpRight,
} from 'lucide-react';

type Message = { role: 'user' | 'assistant'; text: string };

const subjects = [
  'Mathematics', 'Science', 'English', 'English Grammar',
  'Social Studies', 'History', 'Geography', 'Civics',
  'Computer Science', 'Hindi', 'Telugu', 'General Knowledge',
];

function App() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [dark, setDark] = useState(true);
  const [search, setSearch] = useState('');

  const navigation = [
    { label: 'Overview', path: '/', icon: LayoutDashboard },
    { label: 'Classes', path: '/classes', icon: GraduationCap },
    { label: 'Subjects', path: '/subjects', icon: BookOpen },
    { label: 'MEDHIXA AI', path: '/ai', icon: BrainCircuit },
    { label: 'Practice Zone', path: '/practice', icon: ClipboardCheck },
    { label: 'My Progress', path: '/progress', icon: Trophy },
    { label: 'Admin setup', path: '/admin', icon: Settings },
  ];

  return (
    <div className={dark ? 'app dark' : 'app light'}>
      <aside className={`sidebar ${mobileOpen ? 'open' : ''}`}>
        <div className="brand">
          <div className="brand-mark"><BrainCircuit size={23} /></div>
          <div><strong>MEDHIXA</strong><small>INTELLIGENT LEARNING</small></div>
          <button className="mobile-close icon-button" onClick={() => setMobileOpen(false)} aria-label="Close menu"><X /></button>
        </div>
        <div className="nav-label">WORKSPACE</div>
        <nav>
          {navigation.map(({ label, path, icon: Icon }) => (
            <NavLink key={path} to={path} end={path === '/'} onClick={() => setMobileOpen(false)}
              className={({ isActive }) => `nav-item${isActive ? ' active' : ''}`}>
              <Icon size={18} /><span>{label}</span>
              {label === 'MEDHIXA AI' && <span className="ai-tag">AI</span>}
            </NavLink>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="sidebar-promo"><Sparkles size={18} /><strong>Learn beyond limits</strong><p>Your learning journey starts here.</p></div>
          <div className="profile"><div className="avatar">HP</div><div><strong>Student</strong><small>Welcome to MEDHIXA</small></div></div>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <button className="mobile-menu icon-button" onClick={() => setMobileOpen(true)} aria-label="Open menu"><Menu /></button>
          <div className="breadcrumb">MEDHIXA <span>/</span> Learning Space</div>
          <div className="top-actions">
            <label className="search-box"><Search size={16} /><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search learning..." /></label>
            <button className="icon-button" onClick={() => setDark(value => !value)} aria-label="Toggle color theme">{dark ? <Sun size={18} /> : <Moon size={18} />}</button>
          </div>
        </header>

        <div className="content">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/classes" element={<Classes />} />
            <Route path="/subjects" element={<Subjects />} />
            <Route path="/ai" element={<AIChat />} />
            <Route path="/practice" element={<Practice />} />
            <Route path="/progress" element={<Progress />} />
            <Route path="/admin" element={<Admin />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
          <footer>© {new Date().getFullYear()} MEDHIXA · Where Intelligence Meets Innovation.</footer>
        </div>
      </main>
    </div>
  );
}

function Home() {
  const navigate = useNavigate();
  return (
    <>
      <section className="hero">
        <div className="hero-copy">
          <div className="eyebrow"><Sparkles size={14} /> YOUR AI-POWERED LEARNING UNIVERSE</div>
          <h1>LEARN SMARTER.<br /><span>THINK BIGGER.</span><br />ACHIEVE MORE.</h1>
          <p>Explore knowledge, master every subject, and learn with your intelligent study companion.</p>
          <div className="hero-actions">
            <button className="primary-button" onClick={() => navigate('/classes')}>Start Learning <ChevronRight size={17} /></button>
            <button className="secondary-button" onClick={() => navigate('/ai')}><BrainCircuit size={17} /> Ask MEDHIXA AI</button>
          </div>
          <div className="creator">CREATED BY <strong>P. HARIPREETH</strong></div>
        </div>
        <div className="hero-visual" aria-hidden="true">
          <div className="orbital orbital-one" /><div className="orbital orbital-two" /><div className="orbital orbital-three" />
          <div className="orb-core"><BrainCircuit size={65} /></div>
          <span className="orbit-dot dot-one" /><span className="orbit-dot dot-two" /><span className="orbit-dot dot-three" />
        </div>
      </section>

      <section className="section-heading"><div><div className="eyebrow">EXPLORE YOUR POTENTIAL</div><h2>Your learning space</h2></div><span className="muted">Classes 1–10</span></section>
      <div className="stats-grid">
        <Stat icon={<BookOpen />} value="10" label="Classes" />
        <Stat icon={<GraduationCap />} value="12+" label="Subjects" />
        <Stat icon={<BrainCircuit />} value="AI" label="Study assistant" />
        <Stat icon={<Trophy />} value="∞" label="Ways to learn" />
      </div>
      <section className="section-heading"><div><div className="eyebrow">QUICK ACCESS</div><h2>Jump into learning</h2></div></section>
      <div className="feature-grid">
        <Feature icon={<GraduationCap />} title="Explore classes" text="Choose a grade and discover learning resources." onClick={() => navigate('/classes')} />
        <Feature icon={<BrainCircuit />} title="MEDHIXA AI" text="Open the study assistant interface and setup guide." onClick={() => navigate('/ai')} />
        <Feature icon={<ClipboardCheck />} title="Practice zone" text="Try sample questions and check your understanding." onClick={() => navigate('/practice')} />
      </div>
    </>
  );
}

function Stat({ icon, value, label }: { icon: ReactNode; value: string; label: string }) {
  return <div className="stat-card">{icon}<strong>{value}</strong><span>{label}</span></div>;
}

function Feature({ icon, title, text, onClick }: { icon: ReactNode; title: string; text: string; onClick: () => void }) {
  return <button className="feature-card" onClick={onClick}><div className="feature-icon">{icon}</div><h3>{title}</h3><p>{text}</p><span className="text-link">Explore <ChevronRight size={15} /></span></button>;
}

function PageTitle({ eyebrow, title, description }: { eyebrow: string; title: string; description: string }) {
  return <div className="page-title"><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{description}</p></div>;
}

function Classes() {
  return <><PageTitle eyebrow="YOUR ACADEMIC JOURNEY" title="Choose your class" description="Select your grade to explore subjects and learning resources." />
    <div className="class-grid">{Array.from({ length: 10 }, (_, index) => index + 1).map(grade =>
      <a className="class-card" href="/subjects" key={grade}><span>CLASS</span><strong>{grade}</strong><small>Learning resources</small><span className="text-link">Explore subjects <ChevronRight size={14} /></span></a>
    )}</div>
  </>;
}

function Subjects() {
  return <><PageTitle eyebrow="DISCOVER KNOWLEDGE" title="Subject library" description="Explore subjects. Authorized textbook and chapter content can be added as the platform grows." />
    <div className="subject-grid">{subjects.map(subject => <article className="subject-card" key={subject}><div className="feature-icon"><BookMarked size={20} /></div><h3>{subject}</h3><p>Learning notes, worked examples and practice materials.</p><small>Content library ready for setup</small></article>)}</div>
    <div className="notice"><BookOpen size={19} /><p>Use original, licensed, or otherwise authorized learning materials. Sample subject cards are not official textbook content.</p></div>
  </>;
}

function AIChat() {
  const [messages, setMessages] = useState<Message[]>([{ role: 'assistant', text: 'Welcome to MEDHIXA AI. This is the learning chat interface. Connect a secure server-side AI provider to enable real AI-generated answers.' }]);
  const [input, setInput] = useState('');
  const send = () => {
    const question = input.trim();
    if (!question) return;
    setMessages(current => [...current, { role: 'user', text: question }, { role: 'assistant', text: 'Your message was added to this demo conversation. Real AI answers are not enabled yet. A secure backend and server-side API configuration are required.' }]);
    setInput('');
  };
  return <><PageTitle eyebrow="YOUR INTELLIGENT STUDY COMPANION" title="MEDHIXA AI" description="A dedicated study assistant interface, ready for secure AI backend integration." />
    <section className="chat-panel"><div className="chat-header"><div className="feature-icon"><Bot /></div><div><strong>MEDHIXA AI Tutor</strong><small><span className="status-dot" /> Interface ready · AI not connected</small></div></div>
      <div className="messages">{messages.map((message, index) => <div className={`message ${message.role}`} key={`${message.role}-${index}`}><div className="message-icon">{message.role === 'assistant' ? <Bot size={17} /> : <User size={17} />}</div><p>{message.text}</p></div>)}</div>
      <div className="chat-entry"><input value={input} onChange={event => setInput(event.target.value)} onKeyDown={event => { if (event.key === 'Enter') send(); }} placeholder="Ask a learning question..." /><button className="primary-button send-button" onClick={send} aria-label="Send message"><Send size={17} /></button></div>
      <small className="muted">Do not enter private information. The demo does not send messages to an AI service.</small>
    </section>
  </>;
}

function Practice() {
  const [answer, setAnswer] = useState('');
  const [checked, setChecked] = useState(false);
  return <><PageTitle eyebrow="BUILD YOUR CONFIDENCE" title="Practice zone" description="Try this sample question. Additional questions can be added through a future content system." />
    <section className="quiz-card"><div className="eyebrow">SAMPLE · MATHEMATICS</div><h2>What is ¾ + ¼?</h2>
      {['½', '1', '1¼', '2'].map(option => <label className="answer-option" key={option}><input type="radio" name="math-answer" value={option} checked={answer === option} onChange={() => { setAnswer(option); setChecked(false); }} />{option}</label>)}
      <button className="primary-button" disabled={!answer} onClick={() => setChecked(true)}>Check answer</button>
      {checked && <div className={`answer-result ${answer === '1' ? 'correct' : ''}`}>{answer === '1' ? 'Correct! ¾ + ¼ = 4/4 = 1.' : 'Not quite. Add the numerators: 3/4 + 1/4 = 4/4 = 1.'}</div>}
    </section>
  </>;
}

function Progress() {
  return <><PageTitle eyebrow="YOUR JOURNEY" title="My progress" description="Your progress will appear here as you complete lessons and assessments." /><div className="empty-state"><Trophy size={38} /><h2>Your learning journey starts here</h2><p>Complete lessons and practice questions to build your progress history.</p></div></>;
}

function Admin() {
  return <><PageTitle eyebrow="CONTENT MANAGEMENT" title="Admin setup" description="The administrator area needs secure sign-in and server-side permissions before it can manage real content." /><div className="notice"><Settings size={20} /><p>Admin access, role permissions, content editing and database storage must be implemented on a protected backend. This public starter page does not grant admin privileges.</p></div></>;
}

function NotFound() {
  return <div className="empty-state"><h1>Page not found</h1><p>This MEDHIXA page does not exist.</p><a className="primary-button inline-button" href="/">Return home <ArrowUpRight size={16} /></a></div>;
}

export default App;
