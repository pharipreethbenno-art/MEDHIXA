# MEDHIXA

**Where Intelligence Meets Innovation.**  
Creator credit: P. Haripreeth

A React + TypeScript + Vite starter for a futuristic learning platform for Classes 1–10.

## Requirements
- Node.js 20.19+ or 22.12+
- Git
- A GitHub account
- A Vercel account

## Run locally
1. Extract this ZIP.
2. Open the extracted `MEDHIXA` folder in VS Code.
3. Open Terminal → New Terminal.
4. Run:

   ```bash
   npm install
   npm run dev
   ```

5. Open the local URL printed by Vite (usually `http://localhost:5173`).

## Check the production build
Run:

```bash
npm run build
```

A successful build creates the `dist` folder.

## Publish with GitHub + Vercel
1. Create a **public or private** GitHub repository named `MEDHIXA`.
2. Upload the contents of this folder (not the ZIP file itself) to the repository root.
3. In Vercel, choose **Add New → Project** and import the `MEDHIXA` GitHub repository.
4. Keep the framework preset as **Vite**. Build command: `npm run build`. Output directory: `dist`.
5. Select **Deploy**. Vercel will provide the public website URL.
6. For future changes, commit and push to GitHub; Vercel will redeploy automatically.

The included `vercel.json` supports client-side page routes when deployed on Vercel.

## Current feature status
Working in this starter:
- Responsive MEDHIXA interface and navigation
- Classes 1–10 page
- Subject library page
- Sample interactive maths question with feedback
- AI chat interface with clear setup notice
- Progress placeholder and admin setup notice
- Light/dark theme toggle

Not yet connected:
- Real AI model and secure server-side API
- Student sign-in and database persistence
- Protected admin authentication and content management
- Full textbook/chapter/worksheet/exam database

These require a backend and service configuration. Never put an AI API key in frontend code or commit it to GitHub. Use server-side environment variables in Vercel only after a trusted adult has helped review any paid service/account setup.

## Content and copyright
Add only original, licensed, or otherwise authorized learning content. Do not upload complete copyrighted textbooks without permission.
